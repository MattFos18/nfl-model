# NFL Model 3.0

Points-for / points-against prediction and betting model. Plan: "NFL Model 3.0 Plan" doc in the NFL Model project.

## Layout
- `nflmodel/pull.py`   download raw nflverse data (schedules, play-by-play, injuries, snap counts, depth charts, rosters, FTN). Logs every pull to `data/raw/pull_log.csv`.
- `nflmodel/build.py`  build `data/processed/games.parquet` (one row per game, 1999 to now, with closing lines and situational fields) and `data/processed/team_games.parquet` (one row per team per game, 2012 to now, 140 offense and defense stats from play-by-play).
- `data/raw/`          raw downloads (git-ignored, rebuilt by `pull.py`)
- `data/processed/`    built tables (committed so the dashboard and backtest can read them)
- `reports/`           backtest and lab outputs

## Run
```
python -m nflmodel.pull --seasons 2012-2026
python -m nflmodel.build
```
